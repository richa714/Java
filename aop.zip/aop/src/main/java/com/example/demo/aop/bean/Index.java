package com.example.demo.aop.bean;

import java.math.BigDecimal;




public class Index {
	
	private String indexName;
	private BigDecimal mktPrice;
	private String baseCrrncy;
	private Integer quantity;
	
	public Index(String indexName, BigDecimal mktPrice, String baseCrrncy, Integer quantity) {		
		this.indexName = indexName;
		this.mktPrice = mktPrice;
		this.baseCrrncy = baseCrrncy;
		this.quantity = quantity;
	}

	public String getIndexName() {
		return indexName;
	}

	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}

	public BigDecimal getMktPrice() {
		return mktPrice;
	}

	public void setMktPrice(BigDecimal mktPrice) {
		this.mktPrice = mktPrice;
	}

	public String getBaseCrrncy() {
		return baseCrrncy;
	}

	public void setBaseCrrncy(String baseCrrncy) {
		this.baseCrrncy = baseCrrncy;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	
	

}
