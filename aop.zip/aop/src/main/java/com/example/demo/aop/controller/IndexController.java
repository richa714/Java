package com.example.demo.aop.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.example.demo.aop.bean.Index;

import com.example.demo.aop.service.IndexService;

@Controller
public class IndexController {

	@Autowired
	IndexService service;
	
	public void addIndex(Index index)
	{
		
		service.addNewIndex(index);
	}
	
	public List<Index> getAllIndices()
	{
		return service.getAllIndices();
	}
	
	public void deleteIndex(Index index)
	{
		
		service.deleteIndex(index);
	}
}
