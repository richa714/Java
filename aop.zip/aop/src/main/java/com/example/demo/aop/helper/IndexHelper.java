package com.example.demo.aop.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.aop.bean.Index;

@FunctionalInterface
public interface IndexHelper {
	
	  public static List<Index> initialIndices() {
	  
	 
		  List<Index> allIndices=new ArrayList<Index>();
			
				allIndices.add(new Index("CPL",new BigDecimal(345.89088),"INR",57890));
				allIndices.add(new Index("TATA",new BigDecimal(42345.89088),"INR",23));
				allIndices.add(new Index("SGPL",new BigDecimal(35.89088),"USD",4));
				allIndices.add(new Index("ACC",new BigDecimal(1245.89088),"INR",4));
				allIndices.add(new Index("TechM",new BigDecimal(45545.89088),"CAD",656));
				return allIndices;
	  
	  }
	 
	
	public List<Index> addIndex();
}