package com.example.demo.aop.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.aop.bean.Index;
import com.example.demo.aop.dao.IndexDao;

@Component
public class IndexService implements IIndexService{
	Logger LOG= LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	IndexDao dao;
	
	public List<Index> getAllIndices()
	{
		List<Index> allIndices=dao.getAllIndices();
		LOG.info("Total Indices-- {} ",allIndices.size());
		return allIndices;
	}
	public void addNewIndex(Index index)
	{
		dao.addNewIndex(index);
	}
	public void deleteIndex(Index index)
	{
		if(index.getIndexName().equals(null))
			throw new NullPointerException();
		else
		dao.deleteIndex(index);
	}
	

}
