package com.example.demo.aop.aspects;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.example.demo.aop.bean.Index;

@Configuration
@Aspect
public class LoggingAspect {
	Logger LOG=LoggerFactory.getLogger(this.getClass());
	
	
	
	@Before(value="execution(* com.example.demo.aop.service.*.*(..))")
	public void beforeAllServices(JoinPoint joinPoint)
	{
		LOG.info("ASPECT LOG*****************Entering Service Layer--- method--- "+joinPoint);
		Object[] args=joinPoint.getArgs();
		System.out.println(joinPoint.getTarget());
		System.out.println(joinPoint.getThis());
	}
	
	@Before("execution(* com.example.demo.aop.dao.*.*(..))")
	public void beforeAllDAO(JoinPoint joinPoint)
	{
		LOG.info("ASPECT LOG*****************Entering DAO Layer--- method--- "+joinPoint);
	}
	
	//Pointcut to execute on all the methods of classes in a package
		@Pointcut("within(com.example.demo.aop.service.*)")
		public void afterAllServices() {}
		
		@Pointcut("execution(* com.example.demo.aop.dao.*.*(..))")
		public void afterAllDao() {}
		
		@Pointcut("this(com.example.demo.aop.service.IndexService)")
		public void targetPointcut()
		{}
	
		@Pointcut("execution(* com.example.demo.aop.controller.*.*(..)) && args(index)")
		public void controllerPointCut(Index index) {}
		
		
		@Before("controllerPointCut(index)")
		public void controllerAdvice(Index index)
		{
			LOG.info("Entering Controller--argumets---{}",index.getBaseCrrncy());
		}
		
	@After("targetPointcut()")
	public void targetPointcutServiceAdvice()
	{
		LOG.info("ASPECT LOG*****************Target Pointcut Trigerred---");
	}
	
	@After("afterAllDao()")
	public void afterAllDaoAdvice()
	{
		LOG.info("ASPECT LOG*****************Exiting Dao Layer---");
	}
	
@Around("controllerPointCut(index)")

	public void aroundAdvice(ProceedingJoinPoint proceedJoinPoint,Index index) throws Throwable
	{
		long startTime=System.currentTimeMillis();
		proceedJoinPoint.proceed();
		long endTime=System.currentTimeMillis();
		LOG.info("Total time taken by Complete Request to process-- {} ms",endTime-startTime);
	}

	@AfterThrowing(pointcut="afterAllServices()",throwing="ex")
	public void logAfterException(NullPointerException ex) throws Throwable
	{
		LOG.info("ASPECT*********** Null Pointer Exception occured");
	}
	
	
	  @AfterReturning(pointcut="execution(* com.example.demo.aop.controller.IndexController.getAllIndices(..))",returning="index") 
	  public void afterReturnAdvice(List<Index> index) {
	 LOG.info("All Indices Returned");
	 for(Index i:index)
	 {
		 System.out.println(i.getIndexName());
	 }
	 }
	 
}
