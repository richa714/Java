package com.example.demo.aop.service;

import java.util.List;

import com.example.demo.aop.bean.Index;

public interface IIndexService {
	public List<Index> getAllIndices();
	public void addNewIndex(Index index);
	public void deleteIndex(Index index);

}
