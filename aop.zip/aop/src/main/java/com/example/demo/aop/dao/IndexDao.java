package com.example.demo.aop.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.demo.aop.bean.Index;
import com.example.demo.aop.helper.IndexHelper;

@Component
public class IndexDao {
	
	
	List<Index> allIndices;
	
	
	public void addNewIndex(Index index)
	{
		allIndices=getAllIndices();
		allIndices.add(index);
	}

	public void deleteIndex(Index index)
	{
		allIndices=getAllIndices();
		allIndices.remove(index);
	}
	
	public List<Index> getAllIndices()
	{
		allIndices=IndexHelper.initialIndices();
		return allIndices;
	
	}
}
