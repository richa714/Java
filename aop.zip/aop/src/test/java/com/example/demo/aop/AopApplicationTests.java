package com.example.demo.aop;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.aop.bean.Index;
import com.example.demo.aop.controller.IndexController;
import com.example.demo.aop.service.IndexService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AopApplicationTests {

	@Autowired
	IndexService service;
	
	@Autowired
	IndexController ctrl;

	
	@Test
	public void getAllIndicesTest()
	{
		service.getAllIndices();
	}
	
	@Test
	public void controllerArgsTest()
	{
		
		ctrl.addIndex(new Index("Infy",new BigDecimal(3445.89088),"INR",890));
	}
	
	// test to check not matching argumentrs in aspect
	@Test
	public void controllerTest()
	{

		ctrl.getAllIndices();
	}
	
	// Test for AfterThrowing Exception 
	@Test(expected=NullPointerException.class)
	public void controllerExceptionTest()
	{

		ctrl.deleteIndex(new Index(null,new BigDecimal(3445.89088),"INR",890));
	}
	@Test
	public void addNewIndexTest()
	{
		
		service.addNewIndex(new Index("Infy",new BigDecimal(3445.89088),"INR",890));
		//service.addNewIndex(new Index("Infy",new BigDecimal(3445.89088),"INR",890));
		service.getAllIndices();
	}
	
	@Test
	public void deleteIndexTest()
	{
		
	}

}

